---
name: OpenAPI integer compatibility
description: Compatibility note for the workspace's generated Zod client.
---

The current generated Zod package uses Zod 3, while the installed Orval output maps OpenAPI integer schemas to `zod.int()`, which Zod 3 does not expose.

**Why:** Code generation succeeds but the workspace library typecheck fails afterward, blocking all generated hooks.

**How to apply:** Until the generator/dependency versions are aligned, prefer numeric OpenAPI fields for MVP contracts when integer-only validation is not essential; enforce stricter integer validation in the server when required.