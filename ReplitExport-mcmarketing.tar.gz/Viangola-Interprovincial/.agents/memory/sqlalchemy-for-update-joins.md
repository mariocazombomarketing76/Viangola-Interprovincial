---
name: SQLAlchemy row locking with relations
description: PostgreSQL locking constraint for SQLAlchemy queries that eager-load related rows.
---

Do not combine `with_for_update()` with `joinedload()` relationships in PostgreSQL when the eager load creates an outer join. Lock the primary row first, then load related rows separately in the same transaction.

**Why:** PostgreSQL rejects `FOR UPDATE` on the nullable side of an outer join, causing transaction endpoints to return HTTP 500.

**How to apply:** Use a narrow `select(...).with_for_update()` for the payment, booking, or seat being changed; fetch display relationships separately before commit.